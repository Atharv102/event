/* JavaScript (script.js) */
function registerEvent() {
    alert("Registration successful!");
}
